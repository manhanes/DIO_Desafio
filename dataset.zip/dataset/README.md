# Detecção de Objetos com YOLOv8 + Transfer Learning

Projeto que usa YOLOv8 pré-treinado no COCO (80 classes) e aplica **transfer learning** para adicionar novas classes customizadas.

## Estrutura

```
yolo_project/
├── requirements.txt
├── data.yaml                # Configuração do dataset customizado
├── src/
│   ├── 1_prepare_dataset.py # Prepara/organiza o dataset
│   ├── 2_train.py           # Faz o transfer learning
│   ├── 3_detect.py          # Detecta e classifica em uma imagem
│   └── 4_detect_combined.py # Combina modelo COCO + modelo customizado
├── dataset/
│   ├── images/{train,val}
│   └── labels/{train,val}   # Formato YOLO: class cx cy w h (normalizado 0-1)
└── outputs/                 # Imagens com detecções
```

## Como usar

```bash
# 1. Instalar dependências
pip install -r requirements.txt

# 2. Preparar dataset (ver instruções em 1_prepare_dataset.py)
python src/1_prepare_dataset.py

# 3. Treinar (transfer learning sobre yolov8n.pt)
python src/2_train.py

# 4. Inferir em uma imagem
python src/3_detect.py --image caminho/para/imagem.jpg

# 5. (Opcional) Rodar COCO + modelo custom juntos
python src/4_detect_combined.py --image caminho/para/imagem.jpg
```

## Classes customizadas

Neste exemplo, adicionamos 2 novas classes via transfer learning:
- `capacete_seguranca` (EPI)
- `colete_refletivo` (EPI)

Você pode trocar para qualquer domínio (peças de máquina, produtos, animais específicos etc.)
editando `data.yaml` e rotulando suas imagens.

## Formato das labels (YOLO)

Cada imagem `img001.jpg` precisa de um `img001.txt` com uma linha por objeto:

```
<class_id> <cx> <cy> <w> <h>
```

Todos os valores de coordenadas são **normalizados entre 0 e 1** em relação ao tamanho da imagem.
