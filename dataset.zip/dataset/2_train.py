"""
2_train.py
----------
Transfer Learning: parte do YOLOv8n pré-treinado no COCO (80 classes)
e re-treina para detectar as classes customizadas definidas em data.yaml.

Como funciona o transfer learning aqui:
- `YOLO("yolov8n.pt")` carrega pesos treinados no COCO.
- Ao chamar .train() com um data.yaml de OUTRAS classes, o Ultralytics
  substitui a cabeça de detecção para o novo número de classes e mantém
  o backbone + neck com os pesos aprendidos. Isso acelera a convergência
  e exige muito menos dados do que treinar do zero.
- Por padrão o Ultralytics faz fine-tuning de toda a rede (pode-se
  congelar camadas com `freeze=N` para fine-tuning mais conservador).

Obs.: em máquina sem GPU, use imgsz menor e epochs reduzidas apenas para
validar o pipeline. Para resultados reais, use GPU.
"""

from pathlib import Path
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parent.parent
DATA_YAML = ROOT / "data.yaml"


def main() -> None:
    # 1) Carrega modelo pré-treinado no COCO (80 classes conhecidas)
    #    yolov8n = nano (rápido); troque por yolov8s/m/l/x para mais acurácia.
    model = YOLO("yolov8n.pt")

    # 2) Fine-tuning nas NOVAS classes definidas em data.yaml
    #    - freeze=10: congela as 10 primeiras camadas (backbone), treina apenas
    #      neck+head. Útil quando seu dataset custom é pequeno.
    #    - Se tiver bastantes dados, remova `freeze` para afinar a rede inteira.
    results = model.train(
        data=str(DATA_YAML),
        epochs=50,
        imgsz=640,
        batch=16,
        freeze=10,                  # congela backbone -> transfer learning clássico
        patience=15,                # early stopping
        project=str(ROOT / "outputs"),
        name="train_custom",
        pretrained=True,
        optimizer="auto",
        lr0=0.01,
        seed=42,
        device=0,                   # use "cpu" se não tiver GPU
        verbose=True,
    )

    # 3) Validação final
    metrics = model.val()
    print("\n=== Métricas de validação ===")
    print(f"mAP50     : {metrics.box.map50:.4f}")
    print(f"mAP50-95  : {metrics.box.map:.4f}")

    # 4) O melhor peso é salvo automaticamente em:
    #    outputs/train_custom/weights/best.pt
    best = ROOT / "outputs" / "train_custom" / "weights" / "best.pt"
    print(f"\nMelhor modelo salvo em: {best}")
    print("Use este caminho em 3_detect.py --weights")


if __name__ == "__main__":
    main()
