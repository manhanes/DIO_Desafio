"""
1_prepare_dataset.py
--------------------
Valida a estrutura do dataset e dá instruções de rotulagem.

Estrutura esperada:
    dataset/
        images/train/*.jpg
        images/val/*.jpg
        labels/train/*.txt   (mesmo nome da imagem, extensão .txt)
        labels/val/*.txt

Formato YOLO em cada .txt (uma linha por objeto):
    <class_id> <x_center> <y_center> <width> <height>
Todos os valores normalizados entre 0 e 1.

Recomendações para o transfer learning funcionar bem:
    - Pelo menos 100-200 imagens por classe custom (quanto mais, melhor).
    - Diversidade de ângulos, iluminação e fundos.
    - Split ~80% treino / ~20% validação.
    - Use ferramentas como LabelImg, Roboflow ou CVAT para rotular.
"""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
DATASET = ROOT / "dataset"

REQUIRED_DIRS = [
    DATASET / "images" / "train",
    DATASET / "images" / "val",
    DATASET / "labels" / "train",
    DATASET / "labels" / "val",
]

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp"}


def check_structure() -> bool:
    ok = True
    for d in REQUIRED_DIRS:
        if not d.exists():
            print(f"[ERRO] Diretório ausente: {d}")
            ok = False
        else:
            print(f"[OK]   {d}")
    return ok


def check_pairing(split: str) -> None:
    """Verifica se toda imagem tem seu .txt correspondente."""
    img_dir = DATASET / "images" / split
    lbl_dir = DATASET / "labels" / split

    images = [p for p in img_dir.iterdir() if p.suffix.lower() in IMG_EXTS]
    if not images:
        print(f"[AVISO] Nenhuma imagem em {img_dir}. Adicione imagens antes de treinar.")
        return

    missing = []
    for img in images:
        lbl = lbl_dir / f"{img.stem}.txt"
        if not lbl.exists():
            missing.append(img.name)

    print(f"\n[{split}] {len(images)} imagens encontradas.")
    if missing:
        print(f"[{split}] {len(missing)} imagens SEM label:")
        for m in missing[:10]:
            print(f"    - {m}")
        if len(missing) > 10:
            print(f"    ... (+{len(missing) - 10})")
    else:
        print(f"[{split}] Todas as imagens têm labels. ✔")


def main() -> int:
    print("=== Verificação da estrutura do dataset ===\n")
    if not check_structure():
        print("\nCrie os diretórios faltantes e rode novamente.")
        return 1

    check_pairing("train")
    check_pairing("val")

    print("\n=== Próximos passos ===")
    print("1) Coloque suas imagens em dataset/images/{train,val}")
    print("2) Rotule com LabelImg/Roboflow no formato YOLO")
    print("3) Coloque os .txt em dataset/labels/{train,val}")
    print("4) Rode: python src/2_train.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
