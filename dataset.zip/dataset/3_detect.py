"""
3_detect.py
-----------
Lê uma imagem, roda o modelo (customizado ou pré-treinado), desenha
os bounding boxes e o nome da classe, e salva o resultado.

Uso:
    python src/3_detect.py --image foto.jpg
    python src/3_detect.py --image foto.jpg --weights outputs/train_custom/weights/best.pt
    python src/3_detect.py --image foto.jpg --weights yolov8n.pt   # só classes COCO
"""

import argparse
from pathlib import Path

import cv2
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_WEIGHTS = ROOT / "outputs" / "train_custom" / "weights" / "best.pt"
OUTPUT_DIR = ROOT / "outputs"


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Detecção YOLOv8 em imagem.")
    ap.add_argument("--image", required=True, help="Caminho para a imagem de entrada.")
    ap.add_argument(
        "--weights",
        default=str(DEFAULT_WEIGHTS),
        help="Pesos do modelo (.pt). Se best.pt não existir, use yolov8n.pt.",
    )
    ap.add_argument("--conf", type=float, default=0.25, help="Confiança mínima.")
    ap.add_argument("--iou", type=float, default=0.45, help="IoU para NMS.")
    return ap.parse_args()


def draw_detections(image, result) -> None:
    """Desenha caixas e rótulos na imagem (in-place)."""
    names = result.names                    # dict {class_id: nome}
    boxes = result.boxes                    # tensor de detecções

    if boxes is None or len(boxes) == 0:
        print("Nenhum objeto detectado.")
        return

    for box in boxes:
        # Coordenadas xyxy (canto superior-esq / inferior-dir)
        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
        cls_id = int(box.cls[0])
        conf = float(box.conf[0])
        label = f"{names[cls_id]} {conf:.2f}"

        # Cor baseada no id da classe (consistente por classe)
        color = _color_for(cls_id)

        # Retângulo principal
        cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)

        # Fundo do texto para legibilidade
        (tw, th), baseline = cv2.getTextSize(
            label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2
        )
        cv2.rectangle(
            image, (x1, y1 - th - baseline - 4), (x1 + tw + 4, y1), color, -1
        )
        cv2.putText(
            image, label, (x1 + 2, y1 - baseline - 2),
            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA,
        )

        print(f"[DET] {names[cls_id]:20s} conf={conf:.3f}  bbox=({x1},{y1})-({x2},{y2})")


def _color_for(idx: int) -> tuple:
    """Gera cor determinística (BGR) a partir do id da classe."""
    palette = [
        (56, 56, 255), (151, 157, 255), (31, 112, 255), (29, 178, 255),
        (49, 210, 207), (10, 249, 72), (23, 204, 146), (134, 219, 61),
        (52, 147, 26), (187, 212, 0), (168, 153, 44), (255, 194, 0),
        (147, 69, 52), (255, 115, 100), (236, 24, 0), (255, 56, 132),
    ]
    return palette[idx % len(palette)]


def main() -> None:
    args = parse_args()

    img_path = Path(args.image)
    if not img_path.exists():
        raise FileNotFoundError(f"Imagem não encontrada: {img_path}")

    weights_path = Path(args.weights)
    if not weights_path.exists():
        print(f"[AVISO] {weights_path} não existe. Usando yolov8n.pt (só classes COCO).")
        weights_path = "yolov8n.pt"

    print(f"Carregando modelo: {weights_path}")
    model = YOLO(str(weights_path))

    # Inferência
    results = model.predict(
        source=str(img_path),
        conf=args.conf,
        iou=args.iou,
        verbose=False,
    )
    result = results[0]

    # Desenha na imagem original (BGR, via OpenCV)
    image = cv2.imread(str(img_path))
    if image is None:
        raise RuntimeError(f"Falha ao abrir a imagem: {img_path}")

    draw_detections(image, result)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_DIR / f"{img_path.stem}_detected{img_path.suffix}"
    cv2.imwrite(str(out_path), image)
    print(f"\nImagem com detecções salva em: {out_path}")


if __name__ == "__main__":
    main()
