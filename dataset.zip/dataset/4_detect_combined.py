"""
4_detect_combined.py
--------------------
Roda DOIS modelos na mesma imagem e combina as detecções:
    - yolov8n.pt          -> detecta as 80 classes do COCO (ex.: person, car, dog...)
    - best.pt (custom)    -> detecta suas classes novas (ex.: capacete, colete)

Isso atende ao requisito "além das classes já treinadas previamente antes
do transfer learning". Fazemos inferência dupla e aplicamos um NMS simples
para remover sobreposições entre os dois modelos quando existirem.

Uso:
    python src/4_detect_combined.py --image foto.jpg
"""

import argparse
from pathlib import Path

import cv2
import numpy as np
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parent.parent
CUSTOM_WEIGHTS = ROOT / "outputs" / "train_custom" / "weights" / "best.pt"
COCO_WEIGHTS = "yolov8n.pt"
OUTPUT_DIR = ROOT / "outputs"


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--iou", type=float, default=0.5)
    return ap.parse_args()


def run_model(weights: str, image_path: str, conf: float):
    """Retorna lista de detections: (x1,y1,x2,y2, conf, label)."""
    model = YOLO(weights)
    res = model.predict(source=image_path, conf=conf, verbose=False)[0]
    names = res.names
    out = []
    if res.boxes is not None:
        for b in res.boxes:
            x1, y1, x2, y2 = b.xyxy[0].tolist()
            out.append((
                float(x1), float(y1), float(x2), float(y2),
                float(b.conf[0]),
                names[int(b.cls[0])],
            ))
    return out


def iou(a, b) -> float:
    ax1, ay1, ax2, ay2 = a[:4]
    bx1, by1, bx2, by2 = b[:4]
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    area_a = (ax2 - ax1) * (ay2 - ay1)
    area_b = (bx2 - bx1) * (by2 - by1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def merge(dets_a, dets_b, iou_thr: float):
    """Mantém detecções do modelo A; do B só adiciona se não sobrepuser A."""
    merged = list(dets_a)
    for db in dets_b:
        if all(iou(db, da) < iou_thr for da in dets_a):
            merged.append(db)
    return merged


def color_for(label: str) -> tuple:
    # Hash simples para cor consistente por label
    h = sum(ord(c) for c in label)
    palette = [
        (56, 56, 255), (49, 210, 207), (10, 249, 72), (255, 194, 0),
        (236, 24, 0), (255, 56, 132), (134, 219, 61), (23, 204, 146),
    ]
    return palette[h % len(palette)]


def draw(image, dets) -> None:
    for x1, y1, x2, y2, conf, label in dets:
        p1, p2 = (int(x1), int(y1)), (int(x2), int(y2))
        color = color_for(label)
        cv2.rectangle(image, p1, p2, color, 2)
        text = f"{label} {conf:.2f}"
        (tw, th), bl = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
        cv2.rectangle(image, (p1[0], p1[1] - th - bl - 4),
                      (p1[0] + tw + 4, p1[1]), color, -1)
        cv2.putText(image, text, (p1[0] + 2, p1[1] - bl - 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)


def main() -> None:
    args = parse_args()
    img_path = Path(args.image)
    if not img_path.exists():
        raise FileNotFoundError(img_path)

    # 1) Detecções com modelo customizado (novas classes)
    if CUSTOM_WEIGHTS.exists():
        print(f"Rodando modelo customizado: {CUSTOM_WEIGHTS}")
        dets_custom = run_model(str(CUSTOM_WEIGHTS), str(img_path), args.conf)
    else:
        print(f"[AVISO] {CUSTOM_WEIGHTS} não existe. Treine primeiro com 2_train.py")
        dets_custom = []

    # 2) Detecções com modelo COCO (classes originais)
    print(f"Rodando modelo COCO: {COCO_WEIGHTS}")
    dets_coco = run_model(COCO_WEIGHTS, str(img_path), args.conf)

    # 3) Combina: prioriza as do modelo custom; adiciona do COCO se não houver sobreposição
    all_dets = merge(dets_custom, dets_coco, args.iou)

    print(f"\nTotal: {len(all_dets)} detecções "
          f"(custom={len(dets_custom)}, coco_adicionadas={len(all_dets) - len(dets_custom)})")
    for d in all_dets:
        print(f"  {d[5]:20s} conf={d[4]:.3f}")

    # 4) Desenha e salva
    image = cv2.imread(str(img_path))
    draw(image, all_dets)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_DIR / f"{img_path.stem}_combined{img_path.suffix}"
    cv2.imwrite(str(out_path), image)
    print(f"\nSalvo em: {out_path}")


if __name__ == "__main__":
    main()
